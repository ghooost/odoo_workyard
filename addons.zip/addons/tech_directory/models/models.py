# -*- coding: utf-8 -*-

from odoo import models, fields, api

class basic_pricelist(models.Model):
    _name='tech_directory.basic_pricelist'
    name=fields.Char()
    comment=fields.Text()
    reglament_ids=fields.One2many('tech_directory.reglament_item','pricelist_id')
    is_new=fields.Boolean(compute='isNew',readonly=True,default=False)
    extra_service_ids=fields.One2many('tech_directory.extra_service','pricelist_id')

    @api.one
    def isNew(self):
        if(self.id):
            self.is_new=True
        else:
            self.is_new=False

class reglament_item(models.Model):
    _name= 'tech_directory.reglament_item'

    pricelist_id=fields.Many2one('tech_directory.basic_pricelist')
    reglament_id=fields.Many2one('tech_directory.reglament')

    ds_register=fields.Boolean()
    ds_comment=fields.Text()

    ds_sheme_ids=fields.One2many("tech_directory.scheme_item_ds",'reglament_item_id',auto_join=True)
    ds_scheme_formatted=fields.Text(compute='formatSchemes')
    ds_doplata_za_god_ser=fields.Boolean()
    ds_doplata_za_god_ser_price=fields.Float(digits=(10,2))
    ds_doplata_za_god_part=fields.Boolean()
    ds_doplata_za_god_part_price=fields.Float(digits=(10,2))

    ss_register=fields.Boolean()
    ss_comment=fields.Text()

    ss_sheme_ids=fields.One2many("tech_directory.scheme_item_ss",'reglament_item_id')
    ss_scheme_formatted=fields.Text(compute='formatSchemes')

    ss_inspection=fields.Boolean()
    ss_inspection_price=fields.Float(digits=(10,2))
    ss_act_analiza=fields.Boolean()
    ss_act_analiza_price=fields.Float(digits=(10,2))
    ss_doplata_za_god_ser=fields.Boolean()
    ss_doplata_za_god_ser_price=fields.Float(digits=(10,2))
    ss_doplata_za_god_part=fields.Boolean()
    ss_doplata_za_god_part_price=fields.Float(digits=(10,2))

    pi_register=fields.Boolean()
    pi_comment=fields.Text()
    pi_dob_consult=fields.Boolean()
    pi_dob_consult_price=fields.Float(digits=(10,2))
    pi_dob_proto=fields.Boolean()
    pi_dob_proto_price=fields.Float(digits=(10,2))
    pi_ac_consult=fields.Boolean()
    pi_ac_consult_price=fields.Float(digits=(10,2))
    pi_ac_proto=fields.Boolean()
    pi_ac_proto_price=fields.Float(digits=(10,2))

    @api.one
    def formatSchemes(self):
        buf=""
        for record in self.ds_sheme_ids:
            buf+='<tr><td>'+record.scheme_subj+'</td><td>'+str(record.period)+"</td><td>"+str(record.price)+"</td></tr>"
        self.ds_scheme_formatted=buf
        buf=""
        for record in self.ss_sheme_ids:
            buf+='<tr><td>'+record.scheme_subj+'</td><td>'+str(record.period)+"</td><td>"+str(record.price)+"</td></tr>"
        self.ss_scheme_formatted=buf

class scheme_item(models.Model):
    _name='tech_directory.scheme_item'
    scheme_subj=fields.Selection('schemes','Scheme')
    period=fields.Selection('times','Period')
    price=fields.Float(digits=(10,2))
    reglament_item_id=fields.Many2one('tech_directory.reglament_item')
    @api.model
    def schemes(self):
        return [('1d_p','1d part'),('2d_p','2d part')]

    @api.model
    def times(self):
        return [('1', '1 year'), ('2', '2 years'), ('3', '3 years'), ('4', '4 years'), ('5','5 years'),('0','no years')]


class scheme_item_ds(models.Model):
    _name='tech_directory.scheme_item_ds'
    _inherit='tech_directory.scheme_item'

    @api.model
    def schemes(self):
        return [('1d_s','1d_s'),
            ('2d_p','2d_p'),
            ('3d_s','3d_s'),
            ('4d_p','4d_p'),
            ('5d_s','5d_s'),
            ('6d_s','6d_s')]

class scheme_item_ss(models.Model):
    _name='tech_directory.scheme_item_ss'
    _inherit='tech_directory.scheme_item'

    @api.model
    def schemes(self):
        return [('1s_s','1s_s'),
            ('2s_s','2s_s'),
            ('3s_p','3s_p'),
            ('4s_e','4s_e'),
            ('5s_s','5s_s'),
            ('6s_s','6s_s'),
            ('7s_s','7s_s'),
            ('8s_s','8s_s'),
            ('9s_p','9s_p')]

class extra_service(models.Model):
    _name = 'tech_directory.extra_service'
    pricelist_id=fields.Many2one('tech_directory.basic_pricelist')
    extra_service_id=fields.Many2one('tech_directory.extra_service_item')
    group_name=fields.Text(compute='recalcFields')
    is_minimum_price = fields.Boolean()
    price = fields.Float(digits=(10,2))
    price_to_show=fields.Char(compute='getPriceToShow')

    @api.one
    def recalcFields(self):
        self.group_name=self.extra_service_id.group_id.name

        if(self.is_minimum_price == True):
            self.price_to_show='from '+str(self.price)
        else:
            self.price_to_show=str(self.price)
