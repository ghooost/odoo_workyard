# -*- coding: utf-8 -*-

from odoo import models, fields, api
import random

class api_manager(models.Model):

    _inherit = 'res.users'
    use_api = fields.Boolean(default=False)
    key_api = fields.Char(help="The cod need to be 16 symbols (A-z,1-9)")

    def generate_cod(self):
        self.key_api = ''.join((random.choice('123456789'+ 'qwertyuiopasdfghjklzxcvbnm'.upper() + 'qwertyuiopasdfghjklzxcvbnm') for x in range(16)))
