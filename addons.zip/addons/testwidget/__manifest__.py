{
    'name': "testwidget",

    'summary': """
        Custom widget""",

    'description': """
        Long description of module's purpose
    """,

    'author': "My Company",
    'website': "http://www.yourcompany.com",

    'category': 'Uncategorized',
    'version': '0.1',
    'depends': ['base'],
    'data': [
        'testwidget.xml'
        # 'data/tech_directory_grouplist.csv'
    ],
    'application': True,
}
