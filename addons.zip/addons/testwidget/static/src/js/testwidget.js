openerp.testwidget = function(instance, local) {
  alert("HERE?");
  local.ProductsWidget = instance.Widget.extend({
      template: "ProductsWidget",
      init: function(parent, message) {
          alert("HERE?2");
          this._super(parent);
      }
  });
}
