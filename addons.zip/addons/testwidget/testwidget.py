from odoo import models, fields, api

class basic_model(models.Model):
    _name = "testwidget.basic_model"
    message = fields.Text()
