{
    'name': "contact",

    'summary': """
        карточка контактов для handlbook""",

    'description': """
        Long description of module's purpose
    """,

    'author': "My Company",
    'website': "http://www.yourcompany.com",

    'category': 'Uncategorized',
    'version': '0.1',
    'depends': ['base', "mail"],
    'data': [
        "views/res_contact.xml"
    ],
    'application': True,
}
