# -*- coding: utf-8 -*-
from odoo import http
from api_fun import *
import json

class Example(http.Controller):
    @http.route('/example', type='http', auth='public', website=True,csrf=False)
    def render_example_page(self, **post):
        ckecker = check_api(http.request,post)
        # IF api data will true then
        if ckecker['result']:
            # Do somethings    
            resp = json.dumps({
            'data':{"item1":1,"item2":2},
            'res':'200'
            })
            return http.Response(resp, status=ckecker['status'])
        else:
            return http.Response(ckecker['text'], status=ckecker['status'])
