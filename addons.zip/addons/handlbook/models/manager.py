# -*- coding: utf-8 -*-

from odoo import models, fields, api
from rddata import *

class manager(models.Model):
    _name = 'handlbook.manager'

    name = fields.Char(required = 'True')
    phone = fields.Char(required = 'True')
    E_mail = fields.Char()

    client_id = fields.Many2one("handlbook.client",readonly=True)
    manager_fill  = fields.Boolean(store='False')
    comment = fields.Char()

    @api.multi
    @api.onchange("manager_fill")
    def _onchange_field(self):
        d=rdfast()
        for re in self:
            if re.manager_fill:
                re.name = d['fio']
                re.phone = d['phone']
                re.E_mail = d['email']
                re.manager_fill=False
