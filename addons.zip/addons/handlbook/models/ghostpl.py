# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import UserError, RedirectWarning, ValidationError
import re


class ghostpl(models.Model):
    _name = 'handlbook.ghostpl'
    name = fields.Char()
