# -*- coding: utf-8 -*-

from odoo import models, fields, api

from data_data import suggest_api, clean_api
from odoo.exceptions import UserError, RedirectWarning, ValidationError

class nalog_wizard(models.TransientModel):
    _name = 'handlbook.nalog_wizard'
    ogrn = fields.Char(string="Ogrn",placeholder="sdafdasfds")
    # @api.multi
    # @api.onchange("nalog_api")
    # def _onchange_nalog_api(self):
    #     for re in self:
    #         if re.nalog_api:
    #             re.nalog_api = False
    #             if re.factory_ogrn_ogrnip:
    #
    #
    #
    @api.multi
    def button_save(self):
        print 'm00001 wizard------------------------------------------'
        contractor = self.env['handlbook.contractor'].browse(self._context.get('active_id'))
        if len(self.ogrn) in [10,13,15]:
            try:
                res = suggest_api(self.ogrn, 'party')
                data = res["data"]
                value = res["value"]
                unrestricted_value = res["unrestricted_value"]

                contractor.factory_ogrn_ogrnip = data['ogrn']
                contractor.factory_name = data['name']['full_with_opf']
                contractor.factory_name_kratkoe = data['name']['short_with_opf']
                contractor.factory_yuridicheskij_adres = data['address']['unrestricted_value']
                contractor.factory_pochtovyj_adres = data['address']['unrestricted_value']
                contractor.rukovoditel_fio_v_imenitelnom = data['management']['name']
                contractor.rukovoditel_dolzhnost_v_imenitelnom = data['management']['post']
                contractor.factory_inn = data['inn']
                contractor.factory_kpp = data['kpp']
                contractor.factory_okpo = data['okpo']
                contractor.factory_okvehd = data['okved']
                contractor._skloninefio()
                contractor._dolzhnost()
                return {}
            except (ValueError, KeyError, TypeError):
                raise UserError("Some errors in nalog.ru. Please try later")
                print "JSON format error" + str(ValueError)
                return {}

        else:
            raise UserError("You should write 10(INN) or 13(ORGRN) or 15(ORGNIP) symbols. You write {count} symbols.".format(count=str(len(self.ogrn))))
