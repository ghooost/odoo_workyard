{
    'name': "handlbook",

    'summary': """
        Модуль справочников""",

    'description': """
        Long description of module's purpose
    """,

    'author': "My Company",
    'website': "http://www.yourcompany.com",

    'category': 'Uncategorized',
    'version': '0.1',
    'depends': ['base', "mail","contact"],
    'data': [
        'views/reglament.xml',
        'views/client.xml',
        'views/grouplist.xml',
        'views/manager.xml',
        'views/contractor.xml',
        'views/doc_package.xml',
        'views/own_company.xml',
        'views/dogovor.xml',
        'views/dop_dogovor.xml',
        'views/extra_service.xml',
        'views/create_user_list.xml',
        'views/views.xml',
        'views/reglament_item.xml',
        'views/sheme_item.xml',
        
        'wizard/reglament_items_checkbox_wizard.xml',
        'wizard/nalog_wizard.xml',

        'views/menu.xml',

#experimental pricelists
        'views/ghostpl.xml'


        # 'data/handlbook_grouplist.csv'
    ],
    'application': True,
}
