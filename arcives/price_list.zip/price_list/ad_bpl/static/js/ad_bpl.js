odoo.ad_bpl = function(instance, local) {
    alert("odoo.ad_bpl form1");
    var _t = instance.web._t,
        _lt = instance.web._lt;
    var QWeb = instance.web.qweb;

    local.HomePage = instance.Widget.extend({
        start: function() {
            console.log("pet store home page loaded");
        }
    });
    instance.web.client_actions.add('ad_bpl.homepage', 'instance.ad_bpl.HomePage');
}

odoo.define('ad_bpl.MyWidget', function(require) {
  var core = require('web.core');
  var Widget = require('web.Widget');

  function onAction(parent, action){
    alert("onAction!");
  }

  var MyWidget = Widget.extend({
      init:function(parent, options){
        alert("Init");
        var self = this;
        this._super(parent);
        console.log("Init!");
      },
      start: function() {
        this._super(this);
        this.el.append("<div>Hello dear Odoo user!</div>");
      },
      destroy: function() {
        return this._super.apply(this, arguments);
      },
      redraw: function() {
        console.log("redraw!");
      }
  });

  core.view_registry.add('mywidget', MyWidget);
  return MyWidget;

  //core.action_registry.add('ad_bpl.homepage', onAction);
});
