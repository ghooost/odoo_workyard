# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import UserError, RedirectWarning, ValidationError
import re


class ghostpl(models.Model):
    _name = 'handlbook.ghostpl'

    name = fields.Char()
    comment = fields.Text()
    
    ptype = fields.Integer()
    discount = fields.Integer()
    basePrice=fields.Float()
    finPrice=fields.Float(compute='_compute_finPrice')

    @api.depends('discount','basePrice')
    def _compute_finPrice(self):
        self.finPrice=self.discount/100.0*self.basePrice
