# -*- coding: utf-8 -*-

from odoo import models, fields, api


class reglament(models.Model):
    _name = 'handlbook.reglament'

    name = fields.Text('Reglament name')
    number = fields.Char("Reglament number")
    active = fields.Boolean("Active", default=True)
    group_id = fields.Many2one(
        comodel_name="handlbook.grouplist",
        string="Group name")
