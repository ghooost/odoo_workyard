# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import UserError, RedirectWarning, ValidationError
import re


class scheme_item(models.Model):
    _name = 'handlbook.scheme_item'
    scheme_subj = fields.Selection('schemes', 'Scheme')
    price = fields.Float(digits=(10, 2))
    reglament_item_id = fields.Many2one('handlbook.reglament_item')
    is_faled = fields.Boolean(string="Computed if FALSE", default=False)
    type_changed = fields.Char()

    # @api.multi
    # def write(self, vals):
    #     print 'i am in write methods -----------------------'
    #     for record in self:
    #         for c in record.ds_sheme_ids:
    #             if record.type_changed and record.type_changed == "handle" and not self.check_values(value=vals.get('compute_price'), minvalue=vals.get('minimum_price')):
    #                 raise UserError("Whoops. Your hande price is < minimum. Watch out pls")
    #         for c in record.ss_sheme_ids:
    #             if record.type_changed and record.type_changed == "handle" and not self.check_values(value=vals.get('compute_price'), minvalue=vals.get('minimum_price')):
    #                 raise UserError("Whoops. Your hande price is < minimum. Watch out pls")
    #         return super(basic_pricelist, self).write(vals)

    # @api.multi
    # def write(self, vals):
    #     print 'i am in write methods -----------------------'
    #     if not vals.get('minimum_price'):
    #         minimum_price= self.minimum_price
    #     else:
    #         minimum_price=vals.get('minimum_price')
    #
    #     if not vals.get('compute_price'):
    #         compute_price= self.compute_price
    #     else:
    #         compute_price=vals.get('compute_price')
    #     for record in self:
    #         if record.type_changed and record.type_changed == "handle" and not self.check_values(value=compute_price, minvalue=minimum_price):
    #             raise UserError("Whoops. Your hande price is < minimum. Watch out pls")
    #     return super(scheme_item, self).write(vals)

    def check_values(self, value=0, minvalue=0):
        print "-----------------------------------------------------------check_values"
        print value
        print minvalue
        if int(value) >= int(minvalue):
            return True
        else:
            return False

    def _minimum_value(self, reg_name="", rec_name="", type_doc="ds_sheme_ids"):
        minimum = self.env['handlbook.basic_pricelist'].search(
            [('is_minimum', '=', True)], limit=1)
        if minimum:
            result = 0
            if type_doc == "ds_sheme_ids":
                result = minimum.reglament_ids.filtered(lambda record: record.reglament_id_name == reg_name).ds_sheme_ids.filtered(
                    lambda record: record.scheme_subj == rec_name).price
            elif type_doc == "ss_sheme_ids":
                result = minimum.reglament_ids.filtered(lambda record: record.reglament_id_name == reg_name).ss_sheme_ids.filtered(
                    lambda record: record.scheme_subj == rec_name).price
            return result
        else:
            raise UserError(
                "Minimum praise list is not founded. Pls create it")

    # @api.multi
    # def _compute_me(self):
    #     for record in self:
    #         if record.reglament_item_id.pricelist_id.type_list == "user":
    #             if self._name == 'handlbook.scheme_item_ds':
    #                 if record.type_changed and record.type_changed == "computed":
    #                     result= int(record.price*(1-float(record.reglament_item_id.ds_persent)/int('100'))*(1-float(record.reglament_item_id.basic_all_persent)/int('100')))
    #                 else:
    #                     result= record.compute_price
    #
    #                 if self.check_values(value=result, minvalue=record.minimum_price):
    #                     record.compute_price = result
    #                 else:
    #                     record.is_faled = True
    #                     raise ValidationError(str(record.scheme_subj)+' in ds('+ record.reglament_item_id.name +') cannot be < ' +  str(record.minimum_price) + '. Your value:' + str(result))
    #
    #             elif self._name == 'handlbook.scheme_item_ss':
    #                 if record.type_changed and record.type_changed == "computed":
    #                     result= int(record.price*(1-float(record.reglament_item_id.ss_persent)/int('100'))*(1-float(record.reglament_item_id.basic_all_persent)/int('100')))
    #                 else:
    #                     result= record.compute_price
    #                 if self.check_values(value=result, minvalue=record.minimum_price):
    #                     if record.reglament_item_id.ss_inspection:
    #                         result+=float(record.reglament_item_id.ss_inspection_price)
    #                     if record.reglament_item_id.ss_act_analiza:
    #                         result+=float(record.reglament_item_id.ss_act_analiza_price)
    #                     record.compute_price = result
    #                 else:
    #                     record.is_faled = True
    #                     raise ValidationError(str(record.scheme_subj)+' in ss('+ record.reglament_item_id.name +') cannot be < ' +  str(record.minimum_price) + '. Your value:' + str(result))

    @api.constrains('compute_price')
    def validate(self):
        print "----------- validate in sheme"

        # if not vals.get('minimum_price'):
        #     minimum_price= self.minimum_price
        # else:
        #     minimum_price=vals.get('minimum_price')

        # if not vals.get('compute_price'):
        #     compute_price= self.compute_price
        # else:
        #     compute_price=vals.get('compute_price')

        for c in self:
            if c.type_changed == "handle":
                if not c.check_values(value=c.compute_price, minvalue=c.minimum_price):
                    raise ValidationError(
                        "Whoops. Your handle price is < minimum. Watch out pls")
            else:
                print c.price
                print c.reglament_item_id.ds_persent
                print c.reglament_item_id.basic_all_persent

                result = int(c.price * (1 - float(c.reglament_item_id.ds_persent) / int('100'))
                             * (1 - float(c.reglament_item_id.basic_all_persent) / int('100')))

                if not c.check_values(value=result, minvalue=c.minimum_price):
                    raise ValidationError(
                        "Whoops. Your compute  price is < minimum. Watch out pls")

        # return super(reglament_item, self).write(vals)
    @api.multi
    def _compute_me(self):
        for record in self:
            print "------------------- _compute_me - record.reglament_item_id.ds_persent "
            print record.reglament_item_id.ds_persent
            result = int(record.price * (1 - float(record.reglament_item_id.ds_persent) / int(
                '100')) * (1 - float(record.reglament_item_id.basic_all_persent) / int('100')))
            self.compute_price = result
            return self.check_values(value=result, minvalue=record.minimum_price)
            # return {'status':self.check_values(value=result, minvalue=record.minimum_price),'ds_persent':record.scheme_subj,'reglament_item_id.name':record.reglament_item_id.name}
            # raise UserError(str(record.scheme_subj)+' in ds('+ record.reglament_item_id.name +') cannot be < ' +  str(record.minimum_price) + '. Your value:' + str(result))

        # for record in self:
        #     if record.reglament_item_id.pricelist_id.type_list == "user":
        #         if self._name == 'handlbook.scheme_item_ds':
            # if record.type_changed and record.type_changed == "computed":

            # else:
            #     result= record.compute_price

            # if self.check_values(value=result, minvalue=record.minimum_price):
            #     record.compute_price = result
            # else:
            #     record.is_faled = True
            #

            # elif self._name == 'handlbook.scheme_item_ss':
            #     if record.type_changed and record.type_changed == "computed":
            #         result= int(record.price*(1-float(record.reglament_item_id.ss_persent)/int('100'))*(1-float(record.reglament_item_id.basic_all_persent)/int('100')))
            #     else:
            #         result= record.compute_price
            #     if self.check_values(value=result, minvalue=record.minimum_price):
            #         if record.reglament_item_id.ss_inspection:
            #             result+=float(record.reglament_item_id.ss_inspection_price)
            #         if record.reglament_item_id.ss_act_analiza:
            #             result+=float(record.reglament_item_id.ss_act_analiza_price)
            #         record.compute_price = result
            #     else:
            #         record.is_faled = True
            #         raise ValidationError(str(record.scheme_subj)+' in ss('+ record.reglament_item_id.name +') cannot be < ' +  str(record.minimum_price) + '. Your value:' + str(result))

    @api.multi
    def _min_price(self):
        for record in self:
            if self._name == 'handlbook.scheme_item_ds':
                record.minimum_price = self._minimum_value(
                    reg_name=record.reglament_item_id.reglament_id_name, rec_name=record.scheme_subj, type_doc="ds_sheme_ids")
            elif self._name == 'handlbook.scheme_item_ss':
                record.minimum_price = self._minimum_value(
                    reg_name=record.reglament_item_id.reglament_id_name, rec_name=record.scheme_subj, type_doc="ss_sheme_ids")
    minimum_price = fields.Float(compute=_min_price, readonly=True)

    compute_price = fields.Float(readonly=False, store=True)

    @api.multi
    @api.onchange("compute_price")
    def _onchange_compute_price(self):
        print '----------------- _onchange_compute_price'
        self.type_changed = "handle"


class scheme_item_ds(models.Model):
    _name = 'handlbook.scheme_item_ds'
    _inherit = 'handlbook.scheme_item'

    @api.model
    def schemes(self):
        return [('1d_s', '1d_s'),
                ('2d_p', '2d_p'),
                ('3d_s', '3d_s'),
                ('4d_p', '4d_p'),
                ('5d_s', '5d_s'),
                ('6d_s', '6d_s')]


class scheme_item_ss(models.Model):
    _name = 'handlbook.scheme_item_ss'
    _inherit = 'handlbook.scheme_item'

    @api.model
    def schemes(self):
        return [('1s_s', '1s_s'),
                ('2s_s', '2s_s'),
                ('3s_p', '3s_p'),
                ('4s_e', '4s_e'),
                ('5s_s', '5s_s'),
                ('6s_s', '6s_s'),
                ('7s_s', '7s_s'),
                ('8s_s', '8s_s'),
                ('9s_p', '9s_p')]


class scheme_item_pi_dob(models.Model):
    _name = 'handlbook.scheme_item_pi_dob'
    _inherit = 'handlbook.scheme_item'
    # prot-cons

    @api.model
    def schemes(self):
        return [('consult', 'consult'), ('protocol', 'protocol')]


class scheme_item_pi_ac(models.Model):
    _name = 'handlbook.scheme_item_pi_ac'
    _inherit = 'handlbook.scheme_item'

    @api.model
    def schemes(self):
        return [('consult', 'consult'), ('protocol', 'protocol')]
