# -*- coding: utf-8 -*-
from .import o2m_kanban_record
