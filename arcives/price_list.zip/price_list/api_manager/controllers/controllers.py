# -*- coding: utf-8 -*-
from odoo import http

# class ApiManager(http.Controller):
#     @http.route('/api_manager/api_manager/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/api_manager/api_manager/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('api_manager.listing', {
#             'root': '/api_manager/api_manager',
#             'objects': http.request.env['api_manager.api_manager'].search([]),
#         })

#     @http.route('/api_manager/api_manager/objects/<model("api_manager.api_manager"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('api_manager.object', {
#             'object': obj
#         })