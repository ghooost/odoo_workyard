# -*- coding: utf-8 -*-
import random

def search_api(request,login,key):
    result = request.env['res.users'].sudo().search([('login', '=', login),('key_api', '=', key)])
    print result
    if result:
        if result[0].key_api == key:
            return True
        else:
            return False
    else:
        return False

def check_api(request, post, login='',key=''):

    if not 'login' in post :
        return {'text':'login is empty','status':'404','result':False}
    elif not 'key' in post :
        return {'text':'key is empty','status':'404','result':False}
    elif not search_api(request,post['login'],post['key']):
        return {'text':'login/key no matches found ','status':'404','result':False}
    else:
        return {"text":'API IS successfully','status':'200','result':True}
