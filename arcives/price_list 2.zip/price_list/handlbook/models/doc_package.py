# -*- coding: utf-8 -*-

from odoo import models, fields, api


class doc_package(models.Model):
    _name = 'handlbook.doc_package'
    name = fields.Char(required=True, index=True)
    type_komplekt = fields.Selection(
        string="type_komplekt",
        required=True,
        selection=[
            ('dogovor', 'dogovor'),
            ('dop_soglashenoie', 'dop soglashenoie'),
        ], index=True
    )

    type_dogovora = fields.Selection(
        string="type_dogovora",
        required=True,
        selection=[
            ('predoplata', 'predoplata'),
            ('postoplata', 'postoplata'),
            ('other', 'other'),
        ], index=True
    )
    prilojenia = fields.Char()
    comment = fields.Char()
    active = fields.Boolean("Active", default=True)
