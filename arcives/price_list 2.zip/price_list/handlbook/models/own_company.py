# -*- coding: utf-8 -*-

from odoo import models, fields, api
from rddata import *
import datetime


class own_company(models.Model):
    _name = 'handlbook.own_company'
    _inherit='handlbook.rekvizit'
    _rec_name='rek_short_name'
    own_company_my_button_fill = fields.Boolean()
    pricelist_ids = fields.One2many(
        "handlbook.basic_pricelist", "own_company_id")

    def new_pricelist(self):
        view_id = self.env.ref('handlbook.create_user_list_form').id
        new_name = "%(own_company)s - %(time)s" % {'own_company': self.rek_short_name,
                                                   "time": datetime.datetime.today().strftime("%Y-%m-%d-%H.%M.%S")}
        return {
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'target': 'new',
            'res_model': 'handlbook.create_user_list',
            'view_id': view_id,
            'context': {'default_own_company_id': self.id, 'default_client_id': "", 'default_new_name': new_name}
        }

    @api.multi
    @api.onchange("own_company_my_button_fill")
    def _onchange_field(self):
        d = rdfast()
        for re in self:
            if re.own_company_my_button_fill:
                re.inn = rdnums(11)
                re.kpp = rdnums(11)
                re.ogrn_ogrnip = rdnums(11)
                re.okpo = rdnums(12)
                re.okved = rdnums(11)
                re.checking_accound
                re.ban = rdnums(7)
                re.bik = rdnums(8)
                re.short_org_name = d['full_company']
                re.full_org_name = d['full_company']
                re.juredical_address = d['adress']
                re.mail_address = d['adress']
                re.fax = d['phone']
                re.phone1 = d['phone']
                re.E_mail = d['email']
                re.contact_person = d['fio']
                re.manager_roleImPad = d['post']
                re.manager_fioImPad = d['fio']
                re.manager_rolRdPad = d['fio']
                re.manager_fioRdPad = d['fio']
                re.own_company_my_button_fill = False

    active = fields.Boolean(default=True)
    company_type = fields.Selection(
        [('svoe_ur_lico', 'svoe_ur_lico'), ('postavshic', 'postavshic')], default='svoe_ur_lico')

    website = fields.Char()


    is_os = fields.Boolean()
    os_atestat= fields.Char()
    os_reglament_ids = fields.Many2many("handlbook.reglament")
    os_extra_service_ids = fields.Many2many(
        'handlbook.extra_service_group', 'handlbook_extra_service_groups')

    is_lab = fields.Boolean()
    lab_atestat= fields.Char()
    lab_reglament_ids = fields.Many2many("handlbook.reglament")
    lab_extra_service_ids = fields.Many2many(
        'handlbook.extra_service_group', 'handlbook_extra_service_groups')


    import_code = fields.Char(index=True)

    own_company_contact_ids = fields.One2many(
        "handlbook.own_company_contact", inverse_name="own_company_id", index=True)
class own_company_contact(models.Model):
    _name = 'handlbook.own_company_contact'
    _inherit = 'contact.res_contact'
    own_company_id = fields.Many2one(
        comodel_name="handlbook.own_company",
    )
