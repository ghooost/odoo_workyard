# -*- coding: utf-8 -*-

from odoo import models, fields, api


class extra_service_group(models.Model):
    _name = 'handlbook.extra_service_group'
    name = fields.Char(required=True)
    item_ids = fields.One2many('handlbook.extra_service_item', 'group_id')


class extra_service_item(models.Model):
    _name = 'handlbook.extra_service_item'
    name = fields.Text(required=True)
    code_to_import = fields.Char()
    group_id = fields.Many2one('handlbook.extra_service_group')


class extra_service(models.Model):
    _name = 'handlbook.extra_service'
    pricelist_id = fields.Many2one('handlbook.basic_pricelist')
    extra_service_id = fields.Many2one('handlbook.extra_service_item')
    group_name = fields.Text(compute='recalcFields')
    is_minimum_price = fields.Boolean()
    price = fields.Float(digits=(10, 2))
    price_to_show = fields.Char(compute='getPriceToShow')

    @api.one
    def recalcFields(self):
        self.group_name = self.extra_service_id.group_id.name

        if(self.is_minimum_price == True):
            self.price_to_show = 'from ' + str(self.price)
        else:
            self.price_to_show = str(self.price)
