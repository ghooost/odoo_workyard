# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import UserError, RedirectWarning, ValidationError
import re


class basic_pricelist(models.Model):
    _name = 'handlbook.basic_pricelist'
    client_id = fields.Many2one("handlbook.client")
    own_company_id = fields.Many2one("handlbook.own_company")

    name = fields.Char()
    comment = fields.Text()
    all_persent = fields.Integer()
    reglament_ids = fields.One2many(
        'handlbook.reglament_item', 'pricelist_id', store=True, copy=True)
    is_new = fields.Boolean(compute='isNew', readonly=True, default=False)
    extra_service_ids = fields.One2many(
        'handlbook.extra_service', 'pricelist_id', store=True, copy=True)
    type_list = fields.Selection(
        selection=[
            ('based', 'based'),
            ('postavshik', 'postavshik'),
            ('user', 'user'),
        ],
        default='user', store=True
    )
    state = fields.Selection([
        ('new', 'new'),
        ('signed', 'signed'),
    ], default='new')

    is_minimum = fields.Boolean(default=False)
    
    @api.multi
    @api.onchange("all_persent")
    def _basic(self):
        for reglament in self.reglament_ids:
            a = reglament._ds_writer()
            print 'm00010 ----------------------------------------'
            print a
            # print self.reglament_ids.ds_sheme_ids[0].compute_price
            # reglament.write({'ds_sheme_ids': self.reglament_ids.ds_sheme_ids})
            print self.reglament_ids.ds_sheme_ids[0].compute_price
            self.reglament_ids.ds_sheme_ids[0].write(
                {'compute_price': self.reglament_ids.ds_sheme_ids[0].compute_price})

    def init_after_clone(self):
        for reg in self.reglament_ids:
            for ds in reg.ds_sheme_ids:
                ds.compute_price = ds.price

    def checkbox_view(self):
        view_id = self.env.ref('handlbook.user_bpl_form_checkbox').id
        model = 'handlbook.basic_pricelist'
        return {
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': model,
            'res_id': self.id,
            'view_id': view_id
        }

    @api.multi
    def write(self, vals):
        if vals.get('is_minimum') and len(self.env['handlbook.basic_pricelist'].search([('is_minimum', '=', True)], limit=1)):
            raise UserError("Minimum is created yet. Pls change first copy.")
        return super(basic_pricelist, self).write(vals)

    @api.one
    def isNew(self):
        if(self.id):
            self.is_new = True
        else:
            self.is_new = False
