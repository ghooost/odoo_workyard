# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import UserError, RedirectWarning, ValidationError
import re


class rekvizit(models.AbstractModel):
    _name = 'handlbook.rekvizit'

    rek_name = fields.Char(index=True)
    rek_short_name = fields.Char(index=True)
    rek_factory_yuridicheskij_adres = fields.Text()
    rek_factory_pochtovyj_adres = fields.Text()
    rek_phone = fields.Char()
    rek_fax = fields.Char()
    rek_email= fields.Char()
    rek_inn = fields.Char()
    rek_kpp = fields.Char()
    rek_ogrn = fields.Char()
    rek_okpo = fields.Char()
    rek_okved = fields.Char()
    rek_raschetnyj_schet = fields.Char()
    rek_bank = fields.Char()
    rek_korr_schet = fields.Char()
    rek_bik = fields.Char()

    def nalog_api(self):
        view_id = self.env.ref('handlbook.nalog_form_wizard').id
        return {
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'target': 'new',
            'res_model':'handlbook.nalog_wizard',
            'context': {'default_model_name': self._name},
            'view_id': view_id,
            }
