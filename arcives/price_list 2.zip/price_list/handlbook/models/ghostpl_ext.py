# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import UserError, RedirectWarning, ValidationError
import re


class ghostpl_ext(models.Model):
    u'Extra service item for experimental ghostpl'
    _name = 'handlbook.ghostpl_ext'
    pricelist_id = fields.Many2one('handlbook.ghostpl')
    pricelist_ptype = fields.Integer(compute='recalcWithPricelist', readonly=True)
    name = fields.Char()
    #extra_service_id = fields.Many2many('handlbook.extra_service_item')
    price = fields.Float(digits=(10, 2))
    price_to_show=fields.Float(compute='recalcWithPricelist', readonly=True)

    @api.one
    def recalcWithPricelist(self):
        for i in self.pricelist_id:
            self.pricelist_ptype=i.ptype
            #self.price_to_show=self.price
            if i.ptype in ('1','2'):
                self.price_to_show=self.price
            else:
                self.price_to_show=self.price*(1.0-i.discount/100.0)
