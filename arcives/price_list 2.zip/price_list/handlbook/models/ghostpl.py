# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import UserError, RedirectWarning, ValidationError
import re


class ghostpl(models.Model):
    u'Experimental pricelist ghostpl'
    _name = 'handlbook.ghostpl'

    changed = fields.Char()
    name = fields.Char()
    comment = fields.Text()
    discount = fields.Integer()
    ptype = fields.Selection([('1','min'),('2','base'),('3','client'),('4','provider')])

    extra_service_ids = fields.One2many('handlbook.ghostpl_ext', 'pricelist_id')

    @api.onchange("discount")
    def updatePrices(self):
        if self.ptype in ('1,2'):
            for i in self.extra_service_ids:
                i.price_to_show=i.price
        else:
            for i in self.extra_service_ids:
                i.price_to_show=i.price*(1.0-self.discount/100.0)
        self.changed=i.price_to_show
