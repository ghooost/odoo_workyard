# -*- coding: utf-8 -*-

from odoo import models, fields, api
from rddata import *
import datetime

class client(models.Model):
    _name = 'handlbook.client'
    _rec_name = 'client_code'

    client_code = fields.Char(required = 'True')
    independent_client = fields.Boolean()

    manager_gk = fields.Many2many("res.users")
    contractor_ids = fields.One2many("handlbook.contractor","client_id")
    client_my_button_fill  = fields.Boolean()

    pricelist_ids =  fields.One2many("handlbook.basic_pricelist","client_id")
    client_contact_ids = fields.One2many(
        "handlbook.client_contact", inverse_name="client_id")

    def new_pricelist(self):
        view_id = self.env.ref('handlbook.create_user_list_form').id
        new_name = "%(client_name)s - %(time)s" % {'client_name':self.client_code,"time":datetime.datetime.today().strftime("%Y-%m-%d-%H.%M.%S")}
        return {
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'target': 'new',
            'res_model':'handlbook.create_user_list',
            'view_id': view_id,
            'context': {'default_client_id':self.id,'default_new_name':new_name}
        }

    @api.multi
    @api.onchange("client_my_button_fill")
    def _onchange_field(self):
        d=rdfast()
        for re in self:
            if re.client_my_button_fill:
                re.client_code = rdnums(3)+'-'+rdnums(2)
                re.name = d['name']
                re.phone = d['phone']
                re.E_mail = d['email']
                re.contact_person = d['fio']
                re.client_my_button_fill = False

class client_contact(models.Model):
    _name = 'handlbook.client_contact'
    _inherit = 'contact.res_contact'
    client_id = fields.Many2one(
        comodel_name="handlbook.client",
    )
