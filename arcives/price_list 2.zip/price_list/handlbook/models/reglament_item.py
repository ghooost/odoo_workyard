# -*- coding: utf-8 -*-
from odoo import models, fields, api
from odoo.exceptions import UserError, RedirectWarning, ValidationError
import re


class reglament_item(models.Model):
    _name = 'handlbook.reglament_item'
    name = 'reglament_id_name'
    pricelist_id = fields.Many2one('handlbook.basic_pricelist')
    reglament_id = fields.Many2one('handlbook.reglament')
    is_include = fields.Boolean(default=True)

    reglament_id_name = fields.Text(related='reglament_id.name', store=True)
    ds_register = fields.Boolean()
    ds_comment = fields.Text()

    ds_sheme_ids = fields.One2many(
        "handlbook.scheme_item_ds", 'reglament_item_id', auto_join=True, store=True, copy=True)
    ds_persent = fields.Char()
    basic_all_persent = fields.Integer(related='pricelist_id.all_persent')

    def show_user_reg_item_form(self):
        view_id = self.env.ref('handlbook.user_reg_item_form').id
        model = 'handlbook.reglament_item'
        return {
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': model,
            'res_id': self.id,
            'view_id': view_id,
            'flags': {'initial_mode': 'edit'},
        }

    @api.multi
    @api.onchange("ds_persent")
    def _ds_writer(self):
        for record in self:
            isOk = True
            for c in record.ds_sheme_ids:
                c.type_changed = "computed"
                isOk = isOk and c._compute_me()
        res = {}
        if not isOk:
            res['warning'] = {'title': 'WHOOOOPS',
                              'message': 'AAaaaa!' + str(isOk)}
        print 'm0009 --------------------------------'
        print res
        return res

    ds_scheme_formatted = fields.Text(compute='formatSchemes')

    # Отменили по тз
    # ds_doplata_za_god_ser=fields.Boolean()
    # ds_doplata_za_god_ser_price=fields.Float(digits=(10,2))
    # ds_doplata_za_god_part=fields.Boolean()
    # ds_doplata_za_god_part_price=fields.Float(digits=(10,2))

    ss_register = fields.Boolean()
    ss_comment = fields.Text()
    ss_persent = fields.Char()

    ss_sheme_ids = fields.One2many(
        "handlbook.scheme_item_ss", 'reglament_item_id', store=True, copy=True)
    ss_scheme_formatted = fields.Text(compute='formatSchemes')

    ss_inspection = fields.Boolean()
    ss_inspection_price = fields.Float(digits=(10, 2))
    ss_act_analiza = fields.Boolean()
    ss_act_analiza_price = fields.Float(digits=(10, 2))

    # Отменили по тз
    # ss_doplata_za_god_ser=fields.Boolean()
    # ss_doplata_za_god_ser_price=fields.Float(digits=(10,2))
    # ss_doplata_za_god_part=fields.Boolean()
    # ss_doplata_za_god_part_price=fields.Float(digits=(10,2))

    pi_register = fields.Boolean()
    pi_comment = fields.Text()
    pi_dob_ids = fields.One2many(
        "handlbook.scheme_item_pi_dob", 'reglament_item_id', store=True, copy=True)
    pi_ac_ids = fields.One2many(
        "handlbook.scheme_item_pi_ac", 'reglament_item_id', store=True, copy=True)

    @api.one
    def formatSchemes(self):
        buf = ""
        for record in self.ds_sheme_ids:
            buf += '<tr><td>' + record.scheme_subj + '</td><td>' + \
                str(record.price) + '</td><td>' + \
                str(record.compute_price) + '</td></tr>'
        self.ds_scheme_formatted = buf
        buf = ""
        for record in self.ss_sheme_ids:
            buf += '<tr><td>' + record.scheme_subj + \
                '</td><td>' + str(record.price) + "</td></tr>"
        self.ss_scheme_formatted = buf


class pi_item(models.Model):
    _name = 'handlbook.scheme_item'
    price = fields.Float(digits=(10, 2))
    pi_dob_proto_price = fields.Float(digits=(10, 2))


class pi_item(models.Model):
    _name = 'handlbook.scheme_item'
    price = fields.Float(digits=(10, 2))
    pi_dob_proto_price = fields.Float(digits=(10, 2))
