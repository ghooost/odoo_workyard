# -*- coding: utf-8 -*-
from odoo import models, fields, api
from datetime import datetime
from petrovich.main import Petrovich
from petrovich.enums import Case, Gender
from rddata import *


import json


class contractor(models.Model):
    _name = 'handlbook.contractor'
    _inherit='handlbook.rekvizit'
    __rec_name='rek_name'
    client_id = fields.Many2one("handlbook.client")

    contractor_contact_ids = fields.One2many(
        "handlbook.contractor_contact", inverse_name="contractor_id")
    dogovor_ids = fields.One2many('handlbook.dogovor', 'contractor_id')

    my_button_fill = fields.Boolean(store='False')

    is_new = fields.Boolean(compute='isNew', readonly=True, default=False)

    @api.one
    def isNew(self):
        if(self.id):
            self.is_new = True
        else:
            self.is_new = False

    @api.multi
    @api.onchange("my_button_fill")
    def _onchange_field(self):
        d = rdfast()
        fk_name = rdcompany_type() + ' ' + rdcompany()
        for re in self:
            if re.my_button_fill:
                re.my_button_fill = False
                re.rukovoditel_fio_v_imenitelnom = d['fio']
                re.rukovoditel_dolzhnost_v_imenitelnom = d['post']
                re.rukovoditel_osnovanie_doc = rdnums(7)
                re.rukovoditel_phone = d['phone']
                re.rukovoditel_email = d['email']
                re.buhgalter_phone = rdphone()
                re.buhgalter_email = rdemail()
                re.otvetstvennyj_po_sdelke = rdfio()
                re.otvetstvennyj_po_sdelke_phone = rdphone()
                re.otvetstvennyj_po_sdelke_email = rdemail()
                re.factory_name = fk_name
                re.factory_name_kratkoe = fk_name + u' краткое'
                re.factory_yuridicheskij_adres = rdadress()
                re.factory_pochtovyj_adres = rdadress()
                re.factory_inn = rdnums(11)
                re.factory_kpp = rdnums(11)
                re.factory_ogrn_ogrnip = rdnums(11)
                re.factory_okpo = rdnums(11)
                re.factory_okvehd = rdnums(11)
                re.factory_raschetnyj_schet = rdnums(18)
                re.factory_bank = rdnums(9)
                re.factory_korr_schet = rdnums(15)
                re.factory_bik = rdnums(8)


class contractor_contact(models.Model):
    _name = 'handlbook.contractor_contact'
    _inherit = 'contact.res_contact'
    contractor_id = fields.Many2one(
        comodel_name="handlbook.contractor",
    )
