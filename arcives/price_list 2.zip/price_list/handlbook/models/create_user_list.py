# -*- coding: utf-8 -*-

from odoo import models, fields, api
from rddata import *
from odoo.exceptions import UserError, RedirectWarning, ValidationError


class create_user_list(models.TransientModel):
    _name = 'handlbook.create_user_list'
    new_name = fields.Char(required=True)
    basic_pricelist_id = fields.Many2one(string="Choise the default praise list",
                                         comodel_name="handlbook.basic_pricelist",
                                         domain="[('type_list', '=', 'based')]",
                                         help="Choise the default praise list",
                                         )
    client_id = fields.Integer()
    own_company_id = fields.Integer()
    basic_pricelist_comment = fields.Text(
        related='basic_pricelist_id.comment', readonly=True)

    @api.multi
    def button_save(self):
        if not self.basic_pricelist_id:
            raise UserError("Pls choose anyone based pricelist")
        elif not self.new_name:
            raise UserError("Pls write new name to pricelist")
        else:
            serch_res = self.env['handlbook.basic_pricelist'].search(
                [('id', '=', self.basic_pricelist_id.id)])
            default = {
                'comment': 'This list created by......',
                'is_minimum': False,
                'client_id': self.client_id,
                'own_company_id': self.own_company_id,
                'name': self.new_name
            }
            if self.client_id:
                default.update({'type_list': 'user'})
            if self.own_company_id:
                default.update({'type_list': 'postavshik'})

            new_price = serch_res[0].copy(default=default)
            new_price.init_after_clone()
            view_id = self.env.ref('handlbook.user_bpl_form').id
            model = 'handlbook.basic_pricelist'
            return {
                'type': 'ir.actions.act_window',
                'view_type': 'form',
                'view_mode': 'form',
                'target': 'new',
                'res_model': model,
                'res_id': new_price.id,
                'view_id': view_id,
                'flags': {'initial_mode': 'edit'},
            }
