# -*- coding: utf-8 -*-

from odoo import models, fields, api

from data_data import suggest_api, clean_api
from odoo.exceptions import UserError, RedirectWarning, ValidationError

class nalog_wizard(models.TransientModel):
    _name = 'handlbook.nalog_wizard'
    ogrn = fields.Char(string="Ogrn",placeholder="sdafdasfds")
    model_name= fields.Char()
    # @api.multi
    # @api.onchange("nalog_api")
    # def _onchange_nalog_api(self):
    #     for re in self:
    #         if re.nalog_api:
    #             re.nalog_api = False
    #             if re.factory_ogrn_ogrnip:
    #
    #
    #
    @api.multi
    def button_save(self):
        contractor = self.env[self.model_name].browse(self._context.get('active_id'))
        if len(self.ogrn) in [10,13,15]:
            try:
                res = suggest_api(self.ogrn, 'party')
                data = res["data"]
                value = res["value"]
                unrestricted_value = res["unrestricted_value"]
                contractor.rek_ogrn = data['ogrn']
                contractor.rek_name = data['name']['full_with_opf']
                contractor.rek_short_name = data['name']['short_with_opf']
                contractor.rek_factory_yuridicheskij_adres = data['address']['unrestricted_value']
                contractor.rek_factory_pochtovyj_adres = data['address']['unrestricted_value']
                # contractor.rukovoditel_fio_v_imenitelnom = data['management']['name']
                # contractor.rukovoditel_dolzhnost_v_imenitelnom = data['management']['post']
                contractor.rek_inn = data['inn']
                contractor.rek_kpp = data['kpp']
                contractor.rek_okpo = data['okpo']
                contractor.rek_okved = data['okved']
                return {}
            except (ValueError, KeyError, TypeError):
                print "JSON format error" + str(ValueError)
                raise UserError("Some errors in nalog.ru. Please try later")
                return {}
        else:
            raise UserError("You should write 10(INN) or 13(ORGRN) or 15(ORGNIP) symbols. You write {count} symbols.".format(count=str(len(self.ogrn))))
