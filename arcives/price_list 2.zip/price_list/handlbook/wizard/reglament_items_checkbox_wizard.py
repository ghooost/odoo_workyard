# -*- coding: utf-8 -*-

from odoo import models, fields, api


class reglament_items_checkbox_wizard(models.TransientModel):
    _name = 'handlbook.reglament_items_checkbox.wizard'
    name = fields.Char(string="Field name")

    @api.multi
    def button_save(self):
        print self
        # serch_res=self.env['handlbook.basic_pricelist'].search([('id', '=',self.basic_pricelist_id.id )])
        # default={
        # 'comment':'This list created by......',
        # 'is_minimum':False,
        # 'type_list':'user',
        # 'name':self.new_name
        # }
        # new_price = serch_res[0].copy(default=default)
        # view_id = self.env.ref('handlbook.user_bpl_form').id
        # model = 'handlbook.basic_pricelist'
        # return {
        #     'type': 'ir.actions.act_window',
        #     'view_type': 'form',
        #     'view_mode': 'form',
        #     'res_model':model,
        #     'res_id':new_price.id,
        #     'view_id': view_id,
        #     'flags': {'initial_mode': 'edit'},
        # }
