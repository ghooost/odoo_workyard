# -*- coding: utf-8 -*-

from . import reglament_items_checkbox_wizard
from . import nalog_wizard
