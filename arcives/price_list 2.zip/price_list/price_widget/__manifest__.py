# -*- coding: utf-8 -*-
{
    'name': 'Price Widget',
    'version': '1.0.1',
    'category': 'Widget',
    'description': """
    Feature:
        - Price widget for form view

    How to use:
        - Adding widget="Discount" attribute for your Integer field on view
        Ex: <field name="price" widget="Price" />

    """,
    'author': 'AdvDocs',
    'depends': [
        'web',
    ],

    'data': [
        'views/assets.xml'
    ],

    'qweb': ['static/src/xml/price_widget.xml'],
    'js': [],
    'test': [],
    'demo': [],

    'installable': True,
    'active': False,
    'application': True,
}
