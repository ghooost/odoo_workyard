# -*- coding: utf-8 -*-
from odoo import models, fields, api
from datetime import datetime
from petrovich.main import Petrovich
from petrovich.enums import Case, Gender

import json

class res_contact(models.AbstractModel):
    _name = 'contact.res_contact'
    _rec_name = 'name_im_pad'
    name_im_pad = fields.Char(required=True)
    name_rd_pad = fields.Char()

    dolznhost_im_pad_id  = fields.Many2one(
            comodel_name="contact.post",
            )

    dolznhost_rd_pad = fields.Char(related="dolznhost_im_pad_id.post_rd_pad")
    phone = fields.Char()
    email = fields.Char()
    comment = fields.Text()
    osnovanie = fields.Char()

    @api.onchange('name_im_pad')
    def _skloninefio(self):
        if self.name_im_pad:
            fio = self.name_im_pad
            fio = fio.split(' ')
            if len(fio) == 3:
                p = Petrovich()
                surname = fio[0]
                name = fio[1]
                lastname = fio[2]
                self.name_rd_pad = p.lastname(surname, Case.GENITIVE) + ' ' + p.firstname(
                    name, Case.GENITIVE) + ' ' + p.middlename(lastname, Case.GENITIVE)

    # @api.onchange('dolznhost_im_pad')
    # def _dolzhnost(self):
    #     print 'm00008------------------------------------------'
    #     if self.dolznhost_im_pad:
    #         p = Petrovich()
    #         res = ''
    #         for member in dict(self.selection_list)[str(self.dolznhost_im_pad)].split(' '):
    #             if member != '':
    #                 res = res + p.lastname(member, Case.GENITIVE) + ' '
    #                 self.dolznhost_rd_pad = res.strip()
    #     else:
    #         self.dolznhost_rd_pad = ''
