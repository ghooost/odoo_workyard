# -*- coding: utf-8 -*-
from odoo import models, fields, api

class post(models.Model):
    _name = 'contact.post'
    _rec_name= 'post_im_pad'
    post_im_pad=fields.Char()
    post_rd_pad=fields.Char()
